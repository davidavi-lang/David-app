# Como gerar o APK pelo celular

1. Crie uma conta em https://github.com/ se ainda não tiver.
2. Crie um repositório novo, por exemplo `david-app`.
3. Envie todos os arquivos desta pasta para o repositório.
4. Abra a aba **Actions**.
5. Selecione **Build APK do David** e toque em **Run workflow**.
6. Quando terminar, abra a execução concluída, vá em **Artifacts** e baixe `david-apk`.

O modelo Gemma não está incluído. O app deve compilar sem ele e funcionará com os comandos offline básicos. O modelo pode ser adicionado depois em `assets/models/`, se a versão compatível for confirmada.
