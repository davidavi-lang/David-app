# DAVID — Assistente de Voz Android (pt-BR, grátis, sem API paga)

Assistente estilo Jarvis: voz offline do sistema + comandos locais + LLM local opcional.

## Como compilar (Android Studio ou linha de comando)

1. Instale o Flutter SDK: https://docs.flutter.dev/get-started/install
2. `flutter pub get`
3. (Opcional, para o cérebro local) baixe o modelo Gemma 3n E2B INT4 (.task ~1,7 GB):
   - MediaPipe: https://ai.google.dev/edge/mediapipe/solutions/genai/llm_inference/android
   - Coloque em `assets/models/gemma-3n-e2b-int4.task`
   - Sem o arquivo o app funciona normalmente com os comandos offline.
4. `flutter build apk --release`
5. APK em `build/app/outputs/flutter-apk/app-release.apk`

## Permissões que o app pede ao abrir
Microfone, contatos, telefone, notificações, alarme exato, câmera (lanterna).
Sem essas permissões os comandos relacionados falham com aviso falado.

## Comandos de voz (pt-BR)
- "que horas são" / "que dia é hoje"
- "abrir WhatsApp" / "abrir Chrome"
- "ligar para João" (dial, usa contatos)
- "despertar sete horas" / "despertar 7:30"
- "lembrete daqui a 20 minutos comprar pão"
- "lanterna ligada" / "lanterna desligada"
- "volume 60%"
- "pesquisar previsão do tempo"
- "conversar" -> ativa o modo chat (LLM local se disponível)

