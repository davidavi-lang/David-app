package com.david.assistant

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.view.WindowManager
import androidx.core.app.ActivityCompat
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "david/actions"
    private val LLM_CHANNEL = "david/llm"
    private var llm: LlmInference? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "openApp" -> result.success(openApp(call.argument("packageName") ?: ""))
                        "openAppByName" -> result.success(openAppByName(call.argument("name") ?: ""))
                        "dial" -> { dial(call.argument("number") ?: ""); result.success(true) }
                        "call" -> { callNumber(call.argument("number") ?: ""); result.success(true) }
                        "setAlarm" -> { setAlarm(call.argument("hour") ?: 7, call.argument("minute") ?: 0, call.argument("message") ?: "David"); result.success(true) }
                        "flashlight" -> result.success(flashlight(call.argument("on") ?: true))
                        "volume" -> { setVolume(call.argument("percent") ?: 60); result.success(true) }
                        "searchWeb" -> { searchWeb(call.argument("query") ?: ""); result.success(true) }
                        "openUrl" -> { openUrl(call.argument("url") ?: "https://google.com"); result.success(true) }
                        "findContactNumber" -> result.success(findContactNumber(call.argument("name") ?: ""))
                        "keepScreenOn" -> { keepScreenOn(call.argument("on") ?: false); result.success(true) }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("ERR", e.message, null)
                }
            }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, LLM_CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "loadModel" -> result.success(loadLlm(call.argument("path") ?: ""))
                        "generate" -> result.success(generate(call.argument("prompt") ?: ""))
                        "closeModel" -> { llm?.close(); llm = null; result.success(true) }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("ERR", e.message, null)
                }
            }
    }

    private fun openApp(packageName: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
            ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    private fun openAppByName(name: String): Boolean {
        val main = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = packageManager.queryIntentActivities(main, 0)
        for (info in infos) {
            val label = info.loadLabel(packageManager).toString().lowercase()
            if (label.contains(name.lowercase())) {
                val intent = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent!!)
                return true
            }
        }
        return false
    }

    private fun dial(number: String) {
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun callNumber(number: String) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else dial(number)
    }

    private fun setAlarm(hour: Int, minute: Int, message: String) {
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(i)
    }

    private fun flashlight(on: Boolean): Boolean {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { id ->
            cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return false
        cm.setTorchMode(id, on)
        return true
    }

    private fun setVolume(percent: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * percent / 100), 0)
    }

    private fun searchWeb(query: String) {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", query).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun findContactNumber(name: String): String? {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )
        var number: String? = null
        if (cursor != null && cursor.moveToFirst()) {
            number = cursor.getString(0)
            cursor.close()
        }
        return number
    }

    private fun keepScreenOn(on: Boolean) {
        runOnUiThread {
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun loadLlm(path: String): Boolean {
        llm?.close()
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(1024)
            .setTemperature(0.7f)
            .setTopK(40)
            .build()
        llm = LlmInference.createFromOptions(this, options)
        return true
    }

    private fun generate(prompt: String): String {
        return llm?.generateResponse(prompt) ?: "MODELO NAO CARREGADO"
    }
}

