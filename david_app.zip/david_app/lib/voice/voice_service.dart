import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final _stt = SpeechToText();
  final _tts = FlutterTts();
  bool _sttReady = false;

  Future<void> init() async {
    await _tts.setLanguage('pt-BR');
    await _tts.setPitch(1.0);
    await _tts.setSpeechRate(0.52);
    _sttReady = await _stt.initialize(onError: (e) => print('STT erro: $e'));
  }

  bool get isListening => _stt.isListening;

  Future<void> listen(void Function(String text) onResult) async {
    if (!_sttReady) return;
    await _stt.listen(
      onResult: (r) {
        if (r.finalResult) onResult(r.recognizedWords);
      },
      localeId: 'pt_BR',
      listenFor: const Duration(seconds: 8),
      pauseFor: const Duration(seconds: 3),
      partialResults: false,
    );
  }

  Future<void> stopListening() => _stt.stop();

  Future<void> say(String text) async {
    await _tts.stop();
    await _tts.speak(text);
  }
}

