import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

/// LLM local via MediaPipe (Gemma 3n E2B INT4 .task em assets/models/).
/// Se o modelo nao existir, David opera so com os comandos offline.
class LlmLocal {
  static const _ch = MethodChannel('david/llm');
  static bool ready = false;

  static Future<bool> tryLoad() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final target = File('${dir.path}/gemma-3n-e2b-int4.task');
      if (!await target.exists()) {
        // Copia de assets/models/ se o usuario colocou o arquivo la
        try {
          final data = await rootBundle.load('assets/models/gemma-3n-e2b-int4.task');
          await target.writeAsBytes(data.buffer.asUint8List());
        } catch (_) {
          return false;
        }
      }
      await _ch.invokeMethod('loadModel', {'path': target.path});
      ready = true;
      return true;
    } catch (_) {
      ready = false;
      return false;
    }
  }

  static Future<String> generate(String prompt) async {
    if (!ready) return '';
    try {
      return (await _ch.invokeMethod('generate', {'prompt': prompt})) as String? ?? '';
    } catch (_) {
      return '';
    }
  }
}

