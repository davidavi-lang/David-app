import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class Memory {
  static Database? _db;

  static Future<void> init() async {
    final dir = await getApplicationDocumentsDirectory();
    _db = await openDatabase('${dir.path}/david.db', version: 1,
        onCreate: (db, v) async {
      await db.execute(
          'CREATE TABLE prefs(key TEXT PRIMARY KEY, value TEXT)');
      await db.execute(
          'CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, text TEXT, ts INTEGER)');
    });
  }

  static Future<void> savePref(String key, String value) async =>
      _db?.insert('prefs', {'key': key, 'value': value},
          conflictAlgorithm: ConflictAlgorithm.replace);

  static Future<String?> getPref(String key) async {
    final rows = await _db?.query('prefs', where: 'key = ?', whereArgs: [key]);
    return rows?.isNotEmpty == true ? rows!.first['value'] as String : null;
  }

  static Future<void> addHistory(String role, String text) async =>
      _db?.insert('history', {'role': role, 'text': text, 'ts': DateTime.now().millisecondsSinceEpoch});

  static Future<List<Map<String, Object?>>> recentHistory({int n = 20}) async =>
      (await _db?.query('history', orderBy: 'ts DESC', limit: n))?.reversed.toList() ?? [];
}

