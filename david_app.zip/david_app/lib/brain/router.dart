import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../actions/device_actions.dart';
import 'llm_local.dart';
import 'memory.dart';

/// Router: tenta intents offline; se nao bater, chama o LLM local.
class Router {
  static final _notif = FlutterLocalNotificationsPlugin();
  static bool _notifInit = false;

  static Future<void> init() async {
    tzdata.initializeTimeZones();
    if (!_notifInit) {
      await _notif.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ));
      _notifInit = true;
    }
  }

  static Future<String> handle(String raw) async {
    final text = raw.toLowerCase().trim();
    await Memory.addHistory('user', raw);

    String reply;

    // --- INTENTS OFFLINE ---
    if (_any(text, ['que horas', 'hora agora'])) {
      final n = DateTime.now();
      reply = 'São ${n.hour} horas e ${n.minute} minutos.';
    } else if (_any(text, ['que dia', 'data de hoje', 'que data'])) {
      final n = DateTime.now();
      reply = 'Hoje é dia ${n.day} do ${n.month} de ${n.year}.';
    } else if (text.startsWith('abrir ') || text.startsWith('abre ')) {
      final name = text.replaceFirst(RegExp(r'ab(rir|re)\s+'), '').trim();
      final ok = await DeviceActions.openAppByName(name);
      reply = ok ? 'Abrindo $name.' : 'Não encontrei o aplicativo $name.';
    } else if (text.startsWith('ligar para')) {
      final name = text.replaceFirst('ligar para', '').trim();
      final num = await DeviceActions.findContactNumber(name);
      if (num != null) {
        await DeviceActions.dial(num);
        reply = 'Discando para $name.';
      } else {
        reply = 'Não encontrei o número de $name.';
      }
    } else if (text.contains('despertar') || text.contains('acordar')) {
      final t = _extractTime(text);
      await DeviceActions.setAlarm(t.$1, t.$2, 'David');
      reply = 'Despertador das ${t.$1}:${t.$2.toString().padLeft(2, '0')}.';
    } else if (text.contains('lembrete')) {
      reply = await _reminder(text);
    } else if (text.contains('lanterna')) {
      final on = !_any(text, ['deslig']);
      await DeviceActions.flashlight(on);
      reply = on ? 'Lanterna ligada.' : 'Lanterna desligada.';
    } else if (text.contains('volume')) {
      final p = _extractNumber(text) ?? 60;
      await DeviceActions.volume(p);
      reply = 'Volume em $p por cento.';
    } else if (text.startsWith('pesquisar') || text.startsWith('pesquisa')) {
      final q = text.replaceFirst(RegExp(r'pesquisa(r)?\s+'), '');
      await DeviceActions.searchWeb(q);
      reply = 'Pesquisando $q.';
    } else if (_any(text, ['seu nome', 'quem é você', 'quem e voce'])) {
      reply = 'Sou o David, seu assistente pessoal. Sem nuvem, direto no seu aparelho.';
    } else {
      // --- LLM LOCAL ---
      if (LlmLocal.ready) {
        final name = await Memory.getPref('user_name') ?? 'usuário';
        final hist = await Memory.recentHistory();
        final context = hist
            .map((h) => '${h['role']}: ${h['text']}')
            .join('\n');
        final prompt = 'Você é o David, assistente pessoal de $name, em português do Brasil. '
            'Respostas curtas e naturais.\n\nConversa recente:\n$context\n\nDavid:';
        final out = await LlmLocal.generate(prompt);
        reply = out.trim().isEmpty ? _fallback(text) : out.trim();
      } else {
        reply = _fallback(text);
      }
    }

    await Memory.addHistory('david', reply);
    return reply;
  }

  static String _fallback(String text) {
    if (_any(text, ['obrigado', 'valeu'])) return 'De nada!';
    if (_any(text, ['bom dia'])) return 'Bom dia! Em que posso ajudar?';
    if (_any(text, ['boa noite'])) return 'Boa noite! Precisa de algo?';
    if (_any(text, ['boa tarde'])) return 'Boa tarde! Diga aí.';
    return 'Entendi "$text", mas meu modelo de linguagem local ainda não está carregado. '
        'Tente comandos como: abrir algum app, que horas são, lanterna, despertar, volume ou pesquisar.';
  }

  static Future<String> _reminder(String text) async {
    final mins = _extractNumber(text) ?? 10;
    final body = text
        .replaceAll(RegExp(r'lembre(te|te-me)\s*'), '')
        .replaceAll(RegExp(r'daqui a \d+ (minutos?|horas?)\s*'), '')
        .trim();
    final when = tz.TZDateTime.now(tz.local).add(Duration(minutes: mins));
    await _notif.zonedSchedule(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'David',
      body.isEmpty ? 'Lembrete!' : body,
      when,
      const NotificationDetails(
        android: AndroidNotificationDetails('david', 'David',
            importance: Importance.high),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
    return 'Lembrete daqui a $mins minutos${body.isEmpty ? '.' : ': $body.'}';
  }

  static bool _any(String t, List<String> opts) => opts.any(t.contains);

  static int? _extractNumber(String t) {
    final m = RegExp(r'(\d+)').firstMatch(t);
    return m != null ? int.tryParse(m.group(1)!) : null;
  }

  static (int, int) _extractTime(String t) {
    final m = RegExp(r'(\d{1,2})[:h](\d{2})?').firstMatch(t);
    if (m != null) {
      return (int.parse(m.group(1)!), int.parse(m.group(2) ?? '0'));
    }
    final n = _extractNumber(t) ?? 7;
    return (n, 0);
  }
}

