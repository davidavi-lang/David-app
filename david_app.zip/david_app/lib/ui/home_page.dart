import 'package:flutter/material.dart';
import '../brain/llm_local.dart';
import '../brain/memory.dart';
import '../brain/router.dart';
import '../voice/voice_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _voice = VoiceService();
  final _messages = <Map<String, String>>[];
  final _input = TextEditingController();
  bool _listening = false;
  bool _busy = false;
  String _status = 'Toque no anel e fale';

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await _voice.init();
    await Memory.init();
    await Router.init();
    final llm = await LlmLocal.tryLoad();
    setState(() => _status = llm
        ? 'David pronto — LLM local carregado'
        : 'David pronto — comandos offline (LLM local não encontrado)');
  }

  Future<void> _onMicTap() async {
    if (_busy) return;
    setState(() {
      _listening = !_listening;
      _status = _listening ? 'Ouvindo...' : 'Toque no anel e fale';
    });
    if (_listening) {
      await _voice.listen((text) async {
        setState(() => _listening = false);
        await _process(text);
      });
    } else {
      await _voice.stopListening();
    }
  }

  Future<void> _process(String text) async {
    if (text.trim().isEmpty) return;
    setState(() {
      _busy = true;
      _messages.add({'role': 'user', 'text': text});
      _status = 'David está pensando...';
    });
    final reply = await Router.handle(text);
    if (!mounted) return;
    setState(() {
      _messages.add({'role': 'david', 'text': reply});
      _busy = false;
      _status = 'Toque no anel e fale';
    });
    await _voice.say(reply);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.4,
            colors: [Color(0xFF0A1A2F), Color(0xFF05070D)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 16),
              Text('DAVID',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      letterSpacing: 8,
                      color: const Color(0xFF00E5FF),
                      fontWeight: FontWeight.w200)),
              const SizedBox(height: 4),
              Text(_status, style: const TextStyle(color: Colors.white54)),
              const SizedBox(height: 16),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _messages.length,
                  itemBuilder: (_, i) {
                    final m = _messages[i];
                    final isDavid = m['role'] == 'david';
                    return Align(
                      alignment:
                          isDavid ? Alignment.centerLeft : Alignment.centerRight,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.all(12),
                        constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width * 0.75),
                        decoration: BoxDecoration(
                          color: isDavid
                              ? const Color(0xFF123049)
                              : const Color(0xFF1E3A5F),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                              color: const Color(0xFF00E5FF).withOpacity(0.25)),
                        ),
                        child: Text(m['text'] ?? '',
                            style: const TextStyle(color: Colors.white)),
                      ),
                    );
                  },
                ),
              ),
              GestureDetector(
                onTap: _onMicTap,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: _listening ? 110 : 96,
                  height: _listening ? 110 : 96,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: const Color(0xFF00E5FF),
                        width: _listening ? 5 : 2),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xFF00E5FF)
                              .withOpacity(_listening ? 0.6 : 0.25),
                          blurRadius: _listening ? 40 : 18)
                    ],
                  ),
                  child: Icon(
                      _listening ? Icons.mic : Icons.mic_none,
                      size: 44,
                      color: const Color(0xFF00E5FF)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _input,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Ou digite um comando...',
                          hintStyle: const TextStyle(color: Colors.white38),
                          filled: true,
                          fillColor: const Color(0xFF0E1B2A),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(24),
                              borderSide: BorderSide.none),
                        ),
                        onSubmitted: (v) {
                          _input.clear();
                          _process(v);
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    CircleAvatar(
                      backgroundColor: const Color(0xFF00E5FF),
                      child: IconButton(
                        icon: const Icon(Icons.send, color: Colors.black),
                        onPressed: () {
                          final v = _input.text;
                          _input.clear();
                          _process(v);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

