import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'ui/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _requestPermissions();
  runApp(const DavidApp());
}

Future<void> _requestPermissions() async {
  await [
    Permission.microphone,
    Permission.contacts,
    Permission.phone,
    Permission.notification,
    Permission.camera,
    Permission.sensors,
  ].request();
}

class DavidApp extends StatelessWidget {
  const DavidApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'David',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00E5FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

