import 'package:flutter/services.dart';

class DeviceActions {
  static const _ch = MethodChannel('david/actions');

  static Future<bool> openApp(String packageName) async =>
      (await _ch.invokeMethod('openApp', {'packageName': packageName})) == true;

  static Future<bool> openAppByName(String name) async =>
      (await _ch.invokeMethod('openAppByName', {'name': name})) == true;

  static Future<void> dial(String number) =>
      _ch.invokeMethod('dial', {'number': number});

  static Future<void> setAlarm(int hour, int minute, String message) =>
      _ch.invokeMethod('setAlarm', {'hour': hour, 'minute': minute, 'message': message});

  static Future<bool> flashlight(bool on) async =>
      (await _ch.invokeMethod('flashlight', {'on': on})) == true;

  static Future<void> volume(int percent) =>
      _ch.invokeMethod('volume', {'percent': percent});

  static Future<void> searchWeb(String query) =>
      _ch.invokeMethod('searchWeb', {'query': query});

  static Future<String?> findContactNumber(String name) async {
    try {
      return await _ch.invokeMethod('findContactNumber', {'name': name});
    } catch (_) {
      return null;
    }
  }
}

